#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct BadUsbApp BadUsbApp;

#ifdef __cplusplus
}
#endif
