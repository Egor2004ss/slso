ADD_SCENE(bt_settings, start, Start)
ADD_SCENE(bt_settings, forget_dev_confirm, ForgetDevConfirm)
ADD_SCENE(bt_settings, forget_dev_success, ForgetDevSuccess)
