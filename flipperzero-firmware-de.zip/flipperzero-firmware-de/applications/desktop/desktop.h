#pragma once

typedef struct Desktop Desktop;
